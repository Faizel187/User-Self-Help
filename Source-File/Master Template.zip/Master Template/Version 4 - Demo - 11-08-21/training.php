<?php

$title = 'Nkgwete IT Solutions | Help Centere';
$content = '

<!--============= Banner Section Starts Here =============-->
<div class="hero-section bg_img" data-background="assets/images/banner/short-banner.jpg">
    <div class="container">
        <div class="banner-content cl-white">
            <p>Microsoft Teams Training</p>
        </div>
    </div>
</div>
<!--============= Banner Section Ends Here =============-->
<br>
<br>
<p></p>

<!-- SHOW DOCUMENT CONTENT HERE -->

<iframe src="YouTube/youtube1.html" frameborder="0" height="1024px" width="100%"></iframe>

<!--============= Have Questions Section Starts Here =============-->
<div class="have-questions-section mb--70--145">
    <div class="container">
        <div class="have-question-wrapper">
            <div class="row">
                <div class="col-lg-8">
                    <div class="have-question-content">
                        <h2 class="title">Still Have Questions?</h2>
                        <p>Our customer care team is here for you!</p>
                        <a href="#0" class="custom-button">Contact Us</a>
                    </div>
                </div>
                <div class="right-thumb d-none d-lg-block">
                    <img src="assets/images/faq/have-questions.png" alt="faq">
                </div>
            </div>
        </div>
    </div>
</div>
<!--============= Have Questions Section Ends Here =============-->
';



include 'Template.php'

?>